
%% Get data to classify and resize it
%% DONT RUN THIS SECTION, WON'T WORK BECAUSE DATA FOLDERS DON'T EXIST
net = inceptionv3;
inputSize = net.Layers(1).InputSize;
% Fruit data, below code creates struct with images for each class
% Data from kaggle. Link: https://www.kaggle.com/datasets/mbkinaci/fruit-images-for-object-detection
fruit_matrix = [];
k = 1;
for i = 77:95
    IM = imread("C:\Users\teodo\OneDrive\Documents\Advanced_data_analysis_and_machine_learnign\Deep Learning\archive (1)\test_zip\test\apple_"+string(i)+".jpg");
    IM = imresize(IM,inputSize(1:2)); %resize to work for network
    fruit_matrix.apples{k} = IM;
    k = k+1;
end
k = 1;
for i = 77:94
    IM = imread("C:\Users\teodo\OneDrive\Documents\Advanced_data_analysis_and_machine_learnign\Deep Learning\archive (1)\test_zip\test\banana_"+string(i)+".jpg");
    IM = imresize(IM,inputSize(1:2));%resize to work for network
    fruit_matrix.bananas{k} = IM;
    k = k+1;
end
k = 1;
for i = 21:25
    IM = imread("C:\Users\teodo\OneDrive\Documents\Advanced_data_analysis_and_machine_learnign\Deep Learning\archive (1)\test_zip\test\mixed_"+string(i)+".jpg");
    IM = imresize(IM,inputSize(1:2));%resize to work for network
    fruit_matrix.mixed{k} = IM;
    k = k+1;
end
k = 1;
for i = 77:95
    if(i ~= 88)
        IM = imread("C:\Users\teodo\OneDrive\Documents\Advanced_data_analysis_and_machine_learnign\Deep Learning\archive (1)\test_zip\test\orange_"+string(i)+".jpg");
        IM = imresize(IM,inputSize(1:2));%resize to work for network
        fruit_matrix.orange{k} = IM;
        k = k+1;
    end
end
%% Dog data the data was selected from kaggle 
% Link : https://www.kaggle.com/datasets/jessicali9530/stanford-dogs-dataset
k = 1;
%go to directory and extract files in it
file = dir('C:\Users\teodo\OneDrive\Documents\Advanced_data_analysis_and_machine_learnign\Deep Learning\archive (2)\images\Images');
%creates structure with dog breed images and target values for each image
all_pics = [];
for i = 3:length(file)
    full_path_1 =file(i).folder +"\"+ file(i).name;
    file_2 = dir(full_path_1);
    class_name = extractAfter(file(i).name,"-");
    for j = 3:length(file_2)
        full_file = file_2(j).folder +"\"+ file_2(j).name;
        try %Try-catch to skip faulty images
            IM = imread(full_file);
            IM = imresize(IM,inputSize(1:2));%resize to work for network
            all_pics.dogs{k} = IM;
            all_pics.targets{k} = class_name; 
            k = k+1;
        catch
            disp("error")
        end
    end
end
%% RUN THIS SECTION TO GET THE DATA
net = inceptionv3;
inputSize = net.Layers(1).InputSize; 
dog_pics = load("dog_pics.mat").all_pics;
fruit_pics = load("fruit_pics.mat").fruit_matrix;

%% Have a look  at network
analyzeNetwork(net);
% b) I selected the inceptionv3 pretrained cnn, the model architecture
% consists of many convolutional layers, ReLU layers and Batch normalization layers, as well as some avg pooling layers, and one max pooling layer and a fully connected layer. 
% In total the model has 315 layers.
%% Get the possible classes
classNames = net.Layers(end).ClassNames;
numClasses = numel(classNames);
classes= classNames(:);
%for dog classification with cleaned strings later
class = classes;
% It seems that it can classify a lot of different things, like animals,
% objects and foods

%% Classify fruits
classified_apples = [];
for i = 1:length(fruit_pics.apples)
    [label,scores] = classify(net,fruit_pics.apples{i});
    [~,idx] = sort(scores,'descend');
    idx = idx(1);
    classified_apples{i} = classes(idx);
end
accuracy_apples = 14/19;%counted manually as granny smith was the class for apples in the cnn
% Accuracy 0.73

classified_oranges = [];
sum_correct_orange = 0;
for i = 1:length(fruit_pics.orange)
    [label,scores] = classify(net,fruit_pics.orange{i});
    [~,idx] = sort(scores,'descend');
    idx = idx(1);
    classified_orange{i} = classes(idx);
    if(classes(idx)=="orange")
        sum_correct_orange = sum_correct_orange +1;
    end
end
accuracy_orange = sum_correct_orange/length(fruit_pics.orange);
% Accuracy 0.94

classified_bananas = [];
sum_correct_bananas = 0;
for i = 1:length(fruit_pics.bananas)
    [label,scores] = classify(net,fruit_pics.bananas{i});
    [~,idx] = sort(scores,'descend');
    idx = idx(1);
    classified_bananas{i} = classes(idx);
    if(classes(idx)=="banana")
        sum_correct_bananas = sum_correct_bananas +1;
    end
end
accuracy_banana = sum_correct_bananas/length(fruit_pics.bananas);
%Accuracy 1

%% Classify dogs
classified_dogs = [];
sum_correct_dogs = 0;
for i = 1:length(dog_pics.dogs)
    [label,scores] = classify(net,dog_pics.dogs{i});
    %get the class with the highest score
    [~,idx] = sort(scores,'descend');
    idx = idx(1);
    classified_dogs{i} = classes(idx);
    %cleaning up the strings from specal characters
    dog_pics.targets{i}(isletter(dog_pics.targets{i})==0) = [];
    class{idx}(isletter(class{idx})==0) = [];
    %if class is same as target
    if(strcmpi(class{idx},dog_pics.targets{i}) == 1)
        sum_correct_dogs = sum_correct_dogs +1;
    end
end
%%
accuracy_dog_types = sum_correct_dogs/length(dog_pics.dogs);
%Accuracy 92 % 

%% Show image and top options for last dog pic
figure
imshow(dog_pics.dogs{i})

[~,idx] = sort(scores,'descend');
idx = idx(5:-1:1);
classNamesTop = classes(idx);
scoresTop = scores(idx);

figure
barh(scoresTop)
xlim([0 1])
title('Top 5 Predictions')
xlabel('Probability')
yticklabels(classNamesTop)